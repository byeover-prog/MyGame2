using System.IO;
using UnityEngine;

/// <summary>
/// JSON ����/�ε� (��ȭ���� ����)
/// - SO�� ���� ������, JSON�� ��ȭ/�ر�/���� ����
/// </summary>
public sealed class WeaponSaveSystem : MonoBehaviour
{
    private const string FileName = "weapon_save.json";

    public static string SavePath => Path.Combine(Application.persistentDataPath, FileName);

    public static void Save(WeaponSaveData data)
    {
        string json = JsonUtility.ToJson(data, true);
        File.WriteAllText(SavePath, json);
        Debug.Log($"[WeaponSaveSystem] Saved: {SavePath}");
    }

    public static WeaponSaveData Load()
    {
        if (!File.Exists(SavePath))
            return new WeaponSaveData();

        string json = File.ReadAllText(SavePath);
        var data = JsonUtility.FromJson<WeaponSaveData>(json);
        return data ?? new WeaponSaveData();
    }
}
