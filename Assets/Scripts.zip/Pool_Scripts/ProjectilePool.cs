using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class ProjectilePool : MonoBehaviour
{
    [Header("기본 프리팹(선택)")]
    [SerializeField] private GameObject defaultPrefab;

    [Header("프리웜(기본 프리팹용)")]
    [Min(0)]
    [SerializeField] private int prewarmCount = 32;

    [Tooltip("풀에 반납된 오브젝트를 정리할 부모(비우면 자기 Transform)")]
    [SerializeField] private Transform poolRoot;

    private readonly Dictionary<int, Queue<GameObject>> _poolsByPrefabId = new Dictionary<int, Queue<GameObject>>(16);

    private void Awake()
    {
        if (poolRoot == null) poolRoot = transform;

        // 기존 코드가 외부에서 Prewarm을 호출하는 구조일 수도 있어서 강제하지 않음.
        // 다만 defaultPrefab이 있고 prewarmCount > 0이면 기본 프리웜만 수행.
        if (defaultPrefab != null && prewarmCount > 0)
        {
            Prewarm(defaultPrefab, prewarmCount);
        }
    }

    // 기존 호환: WeaponShooterSystem2D 등에서 pool.Prewarm(int) 호출하는 케이스 대응
    public void Prewarm(int count)
    {
        if (defaultPrefab == null) return;
        Prewarm(defaultPrefab, count);
    }

    public void Prewarm(GameObject prefab, int count)
    {
        if (prefab == null) return;
        if (count <= 0) return;

        int id = prefab.GetInstanceID();
        if (!_poolsByPrefabId.TryGetValue(id, out var q))
        {
            q = new Queue<GameObject>(count);
            _poolsByPrefabId.Add(id, q);
        }

        for (int i = 0; i < count; i++)
        {
            var inst = CreateNew(prefab);
            Release(prefab, inst);
        }
    }

    // 기존 호환: AutoShooter2D 등에서 pool.Get()만 부르는 케이스
    public GameObject Get()
    {
        if (defaultPrefab == null)
        {
            Debug.LogError("[ProjectilePool] defaultPrefab이 비어있습니다.", this);
            return null;
        }

        return Get(defaultPrefab, Vector3.zero, Quaternion.identity);
    }

    // 기존 호환: WeaponShooterSystem2D가 부르는 형태
    public GameObject Get(GameObject prefab, Vector3 position, Quaternion rotation)
    {
        if (prefab == null) return null;

        int id = prefab.GetInstanceID();
        if (!_poolsByPrefabId.TryGetValue(id, out var q))
        {
            q = new Queue<GameObject>(8);
            _poolsByPrefabId.Add(id, q);
        }

        GameObject inst = (q.Count > 0) ? q.Dequeue() : CreateNew(prefab);

        Transform t = inst.transform;
        t.SetParent(null, false);
        t.SetPositionAndRotation(position, rotation);

        inst.SetActive(true);

        // Projectile2D가 있으면 "풀 반납" 가능하게 바인딩
        if (inst.TryGetComponent(out Projectile2D projectile2D))
        {
            projectile2D.BindPool(this, prefab);
        }

        // 네 프로젝트에 IPooledProjectile2D 같은 인터페이스가 있다면
        // 여기서 같이 바인딩 해줄 수 있음(파일 확인 필요). 일단은 Projectile2D만 처리.

        return inst;
    }

    // 기존 호환: StraightPooledProjectile2D가 부르는 형태
    public void Release(GameObject prefab, GameObject instance)
    {
        if (prefab == null || instance == null) return;

        int id = prefab.GetInstanceID();
        if (!_poolsByPrefabId.TryGetValue(id, out var q))
        {
            q = new Queue<GameObject>(8);
            _poolsByPrefabId.Add(id, q);
        }

        instance.SetActive(false);

        Transform t = instance.transform;
        t.SetParent(poolRoot, false);

        q.Enqueue(instance);
    }

    private GameObject CreateNew(GameObject prefab)
    {
        var inst = Instantiate(prefab, poolRoot);
        inst.SetActive(false);

        // 생성 시에도 Projectile2D면 바인딩
        if (inst.TryGetComponent(out Projectile2D projectile2D))
        {
            projectile2D.BindPool(this, prefab);
        }

        return inst;
    }
}
