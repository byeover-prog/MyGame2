// UTF-8
using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// 암흑구 투사체.
/// 
/// [아키텍처 최적화]
/// 자식(depth≥2)은 데미지를 주지 않으므로 Collider를 비활성화한다.
/// → Physics2D가 자식 투사체를 아예 추적하지 않음
/// → 15개 중 14개가 물리 시스템에서 제거됨
/// → OnTriggerEnter2D 콜백 0회 (자식은 수명 만료로만 분열)
/// 
/// [적용된 전체 최적화]
/// 1. Static 오브젝트 풀 (Instantiate/Destroy/GC = 0)
/// 2. FragmentBudget (트리 전체 분열 총량 제한)
/// 3. Root만 OverlapCircle (자식은 물리 탐색 0)
/// 4. 자식 Collider 비활성화 (Physics2D 부하 제거)
/// 5. collisionGracePeriod (연쇄 폭발 방지)
/// 6. maxDepth=3 상한
/// 7. 로그는 UNITY_EDITOR에서만
/// </summary>
[DisallowMultipleComponent]
public sealed class DarkOrbProjectile2D : MonoBehaviour
{
    [Header("분열 설정")]
    [SerializeField] private DarkOrbProjectile2D splitSpawnPrefab;
    [Range(1f, 89f)]
    [SerializeField] private float splitAngleDeg = 40f;
    [Min(0f)]
    [SerializeField] private float spawnEps = 0.4f;

    [Header("렉 방지")]
    [Tooltip("생성 직후 충돌 무시 시간(초). 연쇄 폭발 방지.")]
    [SerializeField] private float collisionGracePeriod = 0.05f;

    // ══════════════════════════════════════════════════════
    // FragmentBudget
    // ══════════════════════════════════════════════════════

    public sealed class FragmentBudget
    {
        public int remaining;
        public bool TryConsume(int amount)
        {
            if (remaining < amount) return false;
            remaining -= amount;
            return true;
        }
    }

    // ══════════════════════════════════════════════════════
    // 런타임 파라미터
    // ══════════════════════════════════════════════════════

    private LayerMask _enemyMask;
    private int _damage;
    private float _speed, _life, _age;
    private Vector2 _dir;
    private float _explosionRadius;
    private int _splitCount;
    private float _splitSpeed, _splitLife;
    private int _splitDamage;
    private ProjectilePool2D _splitPool;
    private float _alpha = 0.55f;

    private int _depth = 1, _maxDepth = 1;
    private bool _isRoot;
    private FragmentBudget _budget;

    private bool _inited, _exploding;

    // ── 캐싱 ──────────────────────────────────────────────
    private SpriteRenderer[] _cachedSprites;
    private Collider2D[] _cachedColliders;     // ★ Collider 캐싱
    private bool _componentsCached;
    private readonly Collider2D[] _hits = new Collider2D[32];
    private ContactFilter2D _contactFilter;

    // ══════════════════════════════════════════════════════
    // Static 풀
    // ══════════════════════════════════════════════════════

    private static readonly Dictionary<int, Queue<DarkOrbProjectile2D>> _pool
        = new Dictionary<int, Queue<DarkOrbProjectile2D>>();
    private static Transform _poolRoot, _inactiveRoot;
    private static bool _sceneHookRegistered;

    public static int ActiveCount { get; private set; }

    private int _poolKey;
    private DarkOrbProjectile2D _sourcePrefab;

    private static Transform PoolRoot
    {
        get
        {
            if (_poolRoot == null)
            { var go = new GameObject("[DarkOrbPool]"); DontDestroyOnLoad(go); _poolRoot = go.transform; }
            if (!_sceneHookRegistered)
            { UnityEngine.SceneManagement.SceneManager.sceneUnloaded += OnSceneUnloaded; _sceneHookRegistered = true; }
            return _poolRoot;
        }
    }

    private static Transform InactiveRoot
    {
        get
        {
            if (_inactiveRoot == null)
            { var go = new GameObject("[DarkOrbInactiveRoot]"); go.SetActive(false); DontDestroyOnLoad(go); _inactiveRoot = go.transform; }
            return _inactiveRoot;
        }
    }

    private static void OnSceneUnloaded(UnityEngine.SceneManagement.Scene _)
    {
        foreach (var kvp in _pool)
            while (kvp.Value.Count > 0)
            { var obj = kvp.Value.Dequeue(); if (obj != null) Destroy(obj.gameObject); }
        _pool.Clear();
        ActiveCount = 0;
    }

    // ── Spawn / Return / Prewarm ──────────────────────────

    public static DarkOrbProjectile2D Spawn(DarkOrbProjectile2D prefab,
                                             Vector2 pos, bool autoActivate = true)
    {
        if (prefab == null) return null;
        int key = prefab.GetInstanceID();
        DarkOrbProjectile2D inst = null;

        if (_pool.TryGetValue(key, out var q))
            while (q.Count > 0) { inst = q.Dequeue(); if (inst != null) break; inst = null; }

        if (inst == null)
        {
            inst = Instantiate(prefab, InactiveRoot);
            inst.gameObject.SetActive(false);
            inst.name = prefab.name;
            inst.CacheComponents();
        }

        inst._poolKey = key;
        inst._sourcePrefab = prefab;
        inst.transform.SetParent(null, false);
        inst.transform.position = (Vector3)pos;
        inst.transform.rotation = Quaternion.identity;

        if (autoActivate) inst.gameObject.SetActive(true);
        return inst;
    }

    private void ReturnToPool()
    {
        _inited = false;
        ActiveCount--;
        gameObject.SetActive(false);
        transform.SetParent(PoolRoot, false);
        if (!_pool.ContainsKey(_poolKey))
            _pool[_poolKey] = new Queue<DarkOrbProjectile2D>();
        _pool[_poolKey].Enqueue(this);
    }

    public static void Prewarm(DarkOrbProjectile2D prefab, int count)
    {
        if (prefab == null || count <= 0) return;
        int key = prefab.GetInstanceID();
        if (!_pool.ContainsKey(key)) _pool[key] = new Queue<DarkOrbProjectile2D>();
        for (int i = 0; i < count; i++)
        {
            var inst = Instantiate(prefab, InactiveRoot);
            inst.gameObject.SetActive(false);
            inst.name = prefab.name;
            inst._poolKey = key;
            inst._sourcePrefab = prefab;
            inst.CacheComponents();
            inst.transform.SetParent(PoolRoot, false);
            _pool[key].Enqueue(inst);
        }
    }

    private void CacheComponents()
    {
        if (_componentsCached) return;
        _cachedSprites = GetComponentsInChildren<SpriteRenderer>(true);
        _cachedColliders = GetComponentsInChildren<Collider2D>(true);
        _cachedVFXChild = GetComponent<ProjectileVFXChild>();
        _componentsCached = true;
    }

    private ProjectileVFXChild _cachedVFXChild;

    // ══════════════════════════════════════════════════════
    // Init (Root용 - 외부에서 호출)
    // ══════════════════════════════════════════════════════

    public void Init(
        LayerMask enemyMask, int damage, float speed, float lifeSeconds,
        Vector2 dir, float explosionRadius, int splitCount,
        float splitSpeed, float splitLifeSeconds, int splitDamage,
        ProjectilePool2D splitPool, float orbAlpha)
    {
        _enemyMask = enemyMask;
        _damage = Mathf.Max(1, damage);
        _speed = Mathf.Max(0.1f, speed);
        _life = Mathf.Max(0.05f, lifeSeconds);
        _age = 0f;
        _dir = dir.sqrMagnitude > 0.0001f ? dir.normalized : Vector2.right;
        _explosionRadius = Mathf.Max(0.05f, explosionRadius);
        _splitCount = Mathf.Max(0, splitCount);
        _splitSpeed = Mathf.Max(0.1f, splitSpeed);
        _splitLife = Mathf.Max(0.05f, splitLifeSeconds);
        _splitDamage = Mathf.Max(0, splitDamage);
        _splitPool = splitPool;
        _alpha = Mathf.Clamp01(orbAlpha);

        _depth = 1;
        _maxDepth = SplitCountToMaxDepth(_splitCount);
        _isRoot = true;

        int maxFragments = CalcMaxFragments(_maxDepth);
        _budget = new FragmentBudget { remaining = maxFragments };

        _contactFilter = new ContactFilter2D();
        _contactFilter.SetLayerMask(_enemyMask);
        _contactFilter.useTriggers = true;

        ApplyAlpha(_alpha);

        // ★ Root는 Collider 활성화 (적과 충돌 감지 필요)
        SetCollidersEnabled(true);

        // ★ Root는 VFX 전부 허용 (풀에서 재사용 시 이전 자식 상태 리셋)
        if (!_componentsCached) CacheComponents();
        if (_cachedVFXChild != null)
            _cachedVFXChild.SetVFXEnabled(true, true);

        _inited = true;
        _exploding = false;
        ActiveCount++;
    }

    // ── 자식용 초기화 ─────────────────────────────────────

    private void InitAsChild(
        LayerMask enemyMask, int damage, float speed, float life,
        Vector2 dir, float explosionRadius,
        float splitSpeed, float splitLife, int splitDamage,
        ProjectilePool2D splitPool, float alpha,
        int depth, int maxDepth, FragmentBudget sharedBudget)
    {
        _enemyMask = enemyMask;
        _damage = damage;
        _speed = speed;
        _life = life;
        _age = 0f;
        _dir = dir;
        _explosionRadius = explosionRadius;
        _splitCount = 0;
        _splitSpeed = splitSpeed;
        _splitLife = splitLife;
        _splitDamage = splitDamage;
        _splitPool = splitPool;
        _alpha = alpha;

        _depth = depth;
        _maxDepth = maxDepth;
        _isRoot = false;
        _budget = sharedBudget;

        _contactFilter = new ContactFilter2D();
        _contactFilter.SetLayerMask(_enemyMask);
        _contactFilter.useTriggers = true;

        ApplyAlpha(_alpha);

        // ★★★ 핵심: 자식은 Collider 비활성화
        // 자식은 데미지를 주지 않으므로 Physics2D에서 완전히 제거.
        // 수명 만료로만 분열한다.
        // 이것 하나로 15개 투사체 중 14개가 물리 시스템에서 빠짐.
        SetCollidersEnabled(false);

        // ★ 자식 VFX: 중간 depth는 전부 차단, 최종 depth만 폭발 VFX 허용
        if (!_componentsCached) CacheComponents();
        if (_cachedVFXChild != null)
        {
            if (_depth >= _maxDepth)
                _cachedVFXChild.SetVFXEnabled(false, true);  // 최종: 폭발만
            else
                _cachedVFXChild.SetVFXEnabled(false, false);  // 중간: 전부 차단
        }

        _inited = true;
        _exploding = false;
        ActiveCount++;
    }

    // ── Collider 제어 ─────────────────────────────────────

    private void SetCollidersEnabled(bool enabled)
    {
        if (!_componentsCached) CacheComponents();
        for (int i = 0; i < _cachedColliders.Length; i++)
        {
            if (_cachedColliders[i] != null)
                _cachedColliders[i].enabled = enabled;
        }
    }

    // ── 유틸 ──────────────────────────────────────────────

    private static int SplitCountToMaxDepth(int sc)
    {
        if (sc <= 0) return 1;
        if (sc <= 2) return 2;
        return 3; // 상한: 1→2→4 = 최대 7개
    }

    private static int CalcMaxFragments(int maxDepth)
    {
        int total = 0;
        for (int d = 2; d <= maxDepth; d++)
            total += 1 << (d - 1);
        return total;
    }

    private void ApplyAlpha(float a)
    {
        if (!_componentsCached) CacheComponents();
        for (int i = 0; i < _cachedSprites.Length; i++)
        {
            var sr = _cachedSprites[i]; if (sr == null) continue;
            var c = sr.color; c.a = a; sr.color = c;
        }
    }

    // ══════════════════════════════════════════════════════
    // Update / Trigger
    // ══════════════════════════════════════════════════════

    private void Update()
    {
        if (!_inited) return;
        _age += Time.deltaTime;
        transform.position += (Vector3)(_dir * (_speed * Time.deltaTime));
        if (_age >= _life) Explode((Vector2)transform.position);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // ★ 자식은 Collider가 꺼져있으므로 이 콜백 자체가 발동하지 않음
        if (!_inited || other == null) return;
        if (_age < collisionGracePeriod) return;

        if (((1 << other.gameObject.layer) & _enemyMask.value) != 0)
            Explode((Vector2)transform.position);
    }

    // ══════════════════════════════════════════════════════
    // Explode
    // ══════════════════════════════════════════════════════

    private void Explode(Vector2 pos)
    {
        if (!_inited || _exploding) return;
        _exploding = true;

        // Root만 데미지
        if (_isRoot)
        {
            int count = Physics2D.OverlapCircle(
                pos, _explosionRadius, _contactFilter, _hits);
            for (int i = 0; i < count; i++)
            {
                var h = _hits[i]; if (h == null) continue;
                DamageUtil2D.ApplyDamage(h, _damage);
            }
        }

        // 분열
        if (_depth < _maxDepth && _budget != null && _budget.TryConsume(2))
        {
            Vector2 dirA = Rotate(_dir, +splitAngleDeg).normalized;
            Vector2 dirB = Rotate(_dir, -splitAngleDeg).normalized;
            SpawnChild(pos + dirA * spawnEps, dirA, _depth + 1, _maxDepth);
            SpawnChild(pos + dirB * spawnEps, dirB, _depth + 1, _maxDepth);
        }

        ReturnToPool();
    }

    // ── 분열 자식 ─────────────────────────────────────────

    private void SpawnChild(Vector2 pos, Vector2 d, int childDepth, int maxDepth)
    {
        var child = Spawn(_sourcePrefab, pos, autoActivate: false);
        if (child == null) return;

        int childDmg = (_splitDamage > 0) ? _splitDamage : _damage;

        child.InitAsChild(
            _enemyMask, childDmg, _splitSpeed, _splitLife, d,
            _explosionRadius, _splitSpeed, _splitLife, 0,
            _splitPool, _alpha,
            childDepth, maxDepth, _budget);

        child.gameObject.SetActive(true);
    }

    private static Vector2 Rotate(Vector2 v, float deg)
    {
        float rad = deg * Mathf.Deg2Rad;
        float cos = Mathf.Cos(rad); float sin = Mathf.Sin(rad);
        return new Vector2(v.x * cos - v.y * sin, v.x * sin + v.y * cos);
    }
}